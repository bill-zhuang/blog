#!/bin/bash

echo "PHP Installation"
echo "Install PHP dependency"
yum -y install libxml2-devel.x86_64 openssl-devel.x86_64 libcurl-devel.x86_64 libpng-devel.x86_64 libjpeg-turbo-devel.x86_64 freetype-devel.x86_64

if [ -d /usr/local/php ]; then
	chkconfig php-fpm off
	service php-fpm stop
	rm -rf /etc/init.d/php-fpm
	rm -rf /usr/local/php
fi

cd "$path_prefix"/lnmp
php_version=php-5.5.24
if [ -f "$php_version".tar.gz ]; then
	tar -zxf "$php_version".tar.gz
else
	wget http://cn2.php.net/distributions/"$php_version".tar.gz
fi
cd $php_version
./configure  --prefix=/usr/local/php --enable-fpm --with-fpm-user=daemon \
--with-fpm-group=daemon --with-config-file-path=/usr/local/php/etc \
--with-mysql=mysqlnd --with-mysqli=mysqlnd --with-pdo-mysql=mysqlnd \
--with-iconv --with-iconv-dir --with-freetype-dir --with-jpeg-dir \
--with-png-dir --with-gd --with-zlib --with-libxml-dir --with-curl \
--with-curlwrappers --with-mhash --with-xmlrpc --with-openssl --enable-xml \
--disable-rpath --enable-safe-mode --enable-bcmath --enable-shmop \
--enable-sysvsem --enable-inline-optimization --enable-mbregex \
--enable-mbstring --enable-gd-native-ttf --enable-ftp --enable-pcntl \
--enable-sockets --enable-zip --enable-soap --disable-debug --disable-ipv6
make && make install

if [ -d /usr/local/php ]; then
	cp php.ini-development /usr/local/php/etc/php.ini
	sed -i 's@^;date.timezone.*@date.timezone = Asia/Shanghai@' /usr/local/php/etc/php.ini
	sed -i 's@^;cgi.fix_pathinfo.*@cgi.fix_pathinfo=0@' $php_install_dir/etc/php.ini # for php 5.5 ?
	cp /usr/local/php/etc/php-fpm.conf.default /usr/local/php/etc/php-fpm.conf
	sed -i 's@^;pid.*@pid = /usr/local/php/var/run/php-fpm.pid@' /usr/local/php/etc/php-fpm.conf
	cp sapi/fpm/php-fpm /usr/local/bin
	cp sapi/fpm/init.d.php-fpm /etc/init.d/php-fpm
	chmod a+x /etc/init.d/php-fpm
	chkconfig php-fpm on
fi

cd ../
rm -rf $php_version
