#!/bin/bash

echo "Install PCRE"
echo "Install Compile component"
yum -y install gcc gcc-c++
cd "$path_prefix"/lnmp
pcre_version=pcre-8.36

if [ -d "$path_prefix"/lnmp/"$pcre_version" ]; then
	rm -rf "$path_prefix"/lnmp/"$pcre_version"
fi

if [ -f $pcre_version.tar.gz ]; then
	tar -zxf "$pcre_version".tar.gz
else
	wget ftp://ftp.csx.cam.ac.uk/pub/software/programming/pcre/"$pcre_version".tar.gz
fi
cd $pcre_version
./configure
make && make install

cd ../
rm -rf $pcre_version

if [ -d /usr/local/nginx ]; then
        echo "Nginx Install folder exist, delete now"
        /usr/local/nginx/sbin/nginx -s stop
	chkconfig nginx off
        rm -rf /usr/local/nginx
fi

echo "Install Nginx dependency"
yum -y install zlib-devel.x86_64
nginx_version=nginx-1.8.0
if [ -f $nginx_version.tar.gz ]; then
	tar -zxf "$nginx_version".tar.gz
else
	wget http://nginx.org/download/"$nginx_version".tar.gz
fi
cd $nginx_version
./configure
make && make install

if [ -d /usr/local/nginx ]; then
	/bin/cp "$path_prefix"/nginx.conf /usr/local/nginx/conf/nginx.conf
	mkdir /usr/local/nginx/conf.d
	sed -i 's@^#user.*@user daemon daemon;@' /usr/local/nginx/conf/nginx.conf
	ln -s /usr/local/lib/libpcre.so.1 /lib64
	/usr/local/nginx/sbin/nginx -c /usr/local/nginx/conf/nginx.conf

	/usr/local/nginx/sbin/nginx -s stop

	/bin/cp "$path_prefix"/nginx /etc/rc.d/init.d/nginx
	chmod 775 /etc/rc.d/init.d/nginx
	chkconfig nginx on
	/etc/rc.d/init.d/nginx restart

	#/usr/local/nginx/sbin/nginx #start nginx
	/bin/cp $path_prefix/phpinfo.conf /usr/local/nginx/conf.d/phpinfo.conf
	/bin/cp $path_prefix/index.php /usr/local/nginx/html/index.php
fi

cd ../
rm -rf $nginx_version
