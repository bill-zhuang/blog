#!/bin/bash

echo "MySQL Installation"
echo "Install MySQL Dependency"
cd "$path_prefix"/lnmp
yum -y install ncurses-devel.x86_64
echo "Install CMake for compile MySQL Source"
cmake_version=cmake-3.2.2
if [ -d $cmake_version ]; then
	rm -rf $cmake_version
else
	if [ -f "cmake_version".tar.gz ]; then
		tar -zxf "$cmake_version".tar.gz
	else
		wget http://www.cmake.org/files/v3.2/"$cmake_version".tar.gz
	fi
fi
cd $cmake_version
./configure
gmake && gmake install

cd ../
rm -rf $cmake_version

if [ -d /usr/local/mysql ]; then
	chkconfig mysqld off
	rm -rf /usr/local/mysql
fi

echo "Install MySQL Start"
mysql_version=mysql-5.6.24
if [ -f "$mysql_version".tar.gz ]; then
	tar -zxf "$mysql_version".tar.gz
else
	wget http://dev.mysql.com/get/Downloads/MySQL-5.6/"$mysql_version".tar.gz
fi
cd $mysql_version
cmake .
make && make install

cd ../
rm -rf $mysql_version

if [ -d /usr/local/mysql ]; then
	groupadd mysql
	useradd -r -g mysql mysql
	cd /usr/local/mysql
	chown -R mysql .
	chgrp -R mysql .
	scripts/mysql_install_db --user=mysql --basedir=/usr/local/mysql --datadir=/usr/local/mysql/data
	chown -R root .
	chown -R mysql data
	/bin/cp $path_prefix/my.cnf /etc/my.cnf
	#sed -i 's@^datadir.*@datadir=/usr/local/mysql/data@' /etc/my.cnf
	bin/mysqld_safe --user=mysql &
	cp support-files/mysql.server /etc/init.d/mysqld
	chkconfig mysqld on
	export PATH=/usr/local/mysql/bin:$PATH
	source /etc/profile

	bin/mysql_secure_installation #set rooot password, error here, not go down
fi
