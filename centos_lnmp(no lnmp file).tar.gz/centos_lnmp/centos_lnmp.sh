#!/bin/bash

export PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin
clear
printf "
#########################
#    LNMP for CentOS    #
#########################
"

while :
do
	echo 
	echo 'Please select install option:'
	echo -e "\t\033[32m1\033[0m. Install Nginx"
	echo -e "\t\033[32m2\033[0m. Install PHP"
	echo -e "\t\033[32m3\033[0m. Install MySQL"
	echo -e "\t\033[32m4\033[0m. Install Nginx, PHP, MySQL"
	echo -e "\t\033[32m5\033[0m. Install None"
	read -p "Please input a number:(Default 5 press Enter) " Install_option
	[ -z "$Install_option" ] && $Install_option=5
	if [ $Install_option != 1 -a $Install_option != 2 -a $Install_option != 3 -a $Install_option != 4 -a $Install_option != 5 ]; then
		echo -e "\033[31minput error! Please only input number 1,2,3,4,5\033[0m"
	else
		break
	fi
done

#export pwd
path_prefix=`pwd`
export path_prefix

#untar lnmp.tar.gz
if [ -f lnmp.tar.gz ]; then
	tar -zxf lnmp.tar.gz
else
	mkdir lnmp
fi

#Nginx
if [ $Install_option == 1 -o $Install_option == 4 ]; then
	./centos_nginx.sh
fi

#PHP
if [ $Install_option == 2 -o $Install_option == 4 ]; then
        ./centos_php.sh
fi
#MySQL
if [ $Install_option == 3 -o $Install_option == 4 ]; then
        ./centos_mysql.sh
fi
